# Deploying the Mental Health Intensity Classifier

Your notebook already produces the three artifacts the app needs:
`glove_gru.keras`, `tokenizer.pkl`, `label_encoder.pkl`.

## 0. Files to put together
Put these four files in one folder:
```
deploy/
├── app.py
├── requirements.txt
├── Dockerfile
├── glove_gru.keras       ← from your notebook
├── tokenizer.pkl         ← from your notebook
└── label_encoder.pkl     ← from your notebook
```

## 1. Test locally (no Docker)
```bash
pip install -r requirements.txt
uvicorn app:app --reload
```
Then:
```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"text": "I have been feeling really low and hopeless lately"}'
```

## 2. Test with Docker (matches production)
```bash
docker build -t mental-health-classifier .
docker run -p 8000:8000 mental-health-classifier
```
Same curl command as above should work.

## 3. Deploy — pick one

### Option A: Hugging Face Spaces (free, easiest, GPU optional)
1. Create a new Space → SDK: **Docker**.
2. Push this folder's contents (including the Dockerfile) to the Space repo.
3. HF builds and hosts it automatically at
   `https://huggingface.co/spaces/<you>/<space-name>`.
4. Good fit for a portfolio/demo link on your resume.

### Option B: Render.com (free tier)
1. Push this folder to a GitHub repo.
2. Render dashboard → New → Web Service → connect the repo.
3. Environment: **Docker** (it auto-detects the Dockerfile).
4. Deploy. You get a public URL like `https://your-app.onrender.com`.
   (Free tier sleeps after inactivity — first request after idle is slow.)

### Option C: Railway.app
1. Push to GitHub.
2. New Project → Deploy from repo → it detects the Dockerfile automatically.
3. Add a generated domain in the Networking tab.

### Option D: Fly.io (more control, still free-tier friendly)
```bash
fly launch     # detects Dockerfile, creates fly.toml
fly deploy
```

## 4. Model size note
`tensorflow-cpu` + your GloVe-embedding weights can push the image toward
several hundred MB–1GB depending on vocabulary size. If a free tier's build
times out or the memory limit is tight:
- Switch to `tensorflow-cpu` (already done above) instead of full `tensorflow`.
- Consider trimming the embedding matrix to only words that appear in your
  training vocabulary (you likely already do this, since it's built from
  `tokenizer.word_index`).
- HF Spaces generally have the most headroom for this kind of model.

## 5. Before sharing this publicly
This model predicts an "intensity" label from free text about mental health.
A few things worth doing before putting it in front of real users:
- Keep the disclaimer in the API response (already included) visible in
  whatever frontend you build — don't let the label look like a diagnosis.
- If this is user-facing (not just a resume demo), add a visible link to a
  crisis line (e.g., in India, iCall: 9152987821, or Vandrevala Foundation:
  1860-2662-345) regardless of what the model predicts.
- Log prediction confidence — if it's low, say so rather than presenting the
  top label with false certainty.

## 6. Suggested resume framing
"Deployed a GloVe+GRU NLP classifier as a containerized FastAPI microservice
on [Render/HF Spaces], with preprocessing (tokenization, stopword filtering,
lemmatization) mirrored between training and inference to avoid train/serve
skew."
