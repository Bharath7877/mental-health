"""
FastAPI inference service for the GloVe+GRU mental-health intensity classifier.

Expects these files to sit alongside this script (produced by your notebook):
  - glove_gru.keras
  - tokenizer.pkl
  - label_encoder.pkl
"""

import pickle
import re

import nltk
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences

# --- One-time setup -----------------------------------------------------

for pkg in ["punkt", "punkt_tab", "stopwords", "wordnet"]:
    nltk.download(pkg, quiet=True)

MAXLEN = 100  # must match training (pad_sequences(..., maxlen=100))

STOP_WORDS = set(stopwords.words("english"))
KEEP_WORDS = {
    "not", "no", "nor", "never",
    "don't", "didn't", "doesn't",
    "can't", "won't", "isn't",
    "aren't", "wasn't", "weren't",
    "couldn't", "shouldn't", "wouldn't",
    "haven't", "hasn't", "hadn't",
}
CUSTOM_STOPWORDS = STOP_WORDS - KEEP_WORDS
LEMMATIZER = WordNetLemmatizer()

print("Loading model + preprocessing artifacts...")
model = load_model("glove_gru.keras")
with open("tokenizer.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("label_encoder.pkl", "rb") as f:
    label_encoder = pickle.load(f)
print("Ready.")


def preprocess(text: str):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+|https\S+", "", text)
    text = re.sub(r"<.*?>", "", text)
    text = re.sub(r"[^\w\s']", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    words = word_tokenize(text)
    words = [w for w in words if w.lower() not in CUSTOM_STOPWORDS]
    words = [LEMMATIZER.lemmatize(w, pos="v") for w in words]
    return words


# --- API -----------------------------------------------------------------

app = FastAPI(title="Mental Health Intensity Classifier")


class PredictRequest(BaseModel):
    text: str


class PredictResponse(BaseModel):
    label: str
    confidence: float
    probabilities: dict
    disclaimer: str = (
        "This is an automated screening signal from a text classifier, "
        "not a clinical diagnosis. If you or someone you know is in "
        "distress, please reach out to a mental health professional or "
        "a crisis line."
    )


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    tokens = preprocess(req.text)
    seq = tokenizer.texts_to_sequences([tokens])
    padded = pad_sequences(seq, maxlen=MAXLEN)

    probs = model.predict(padded, verbose=0)[0]
    idx = int(np.argmax(probs))
    label = label_encoder.inverse_transform([idx])[0]

    prob_map = {
        str(cls): float(p)
        for cls, p in zip(label_encoder.classes_, probs)
    }

    return PredictResponse(
        label=str(label),
        confidence=float(probs[idx]),
        probabilities=prob_map,
    )
